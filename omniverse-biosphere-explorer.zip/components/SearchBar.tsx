
import React, { useState } from 'react';
import { SearchIcon } from './icons/SearchIcon';

interface SearchBarProps {
  onGenerate: (query: string) => void;
  isLoading: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({ onGenerate, isLoading }) => {
  const [query, setQuery] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onGenerate(query.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative mb-4">
      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
        <SearchIcon className="h-5 w-5 text-slate-500" />
      </div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Explore anything... e.g., 'A Dragon's Lair' or 'Charizard'"
        disabled={isLoading}
        className="w-full pl-11 pr-32 py-4 text-lg bg-slate-800 border border-slate-700 rounded-full focus:ring-2 focus:ring-cyan-500 focus:outline-none text-slate-100 placeholder-slate-500 transition-shadow"
      />
      <button
        type="submit"
        disabled={isLoading || !query.trim()}
        className="absolute inset-y-0 right-0 m-2 px-6 py-2 bg-gradient-to-r from-cyan-500 to-teal-600 text-white font-semibold rounded-full hover:from-cyan-400 hover:to-teal-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
      >
        {isLoading ? 'Exploring...' : 'Generate'}
      </button>
    </form>
  );
};
