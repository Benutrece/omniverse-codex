import React from 'react';
import { Entry } from '../types';
import { BookmarkIcon } from './icons/BookmarkIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface ContentDisplayProps {
  isLoading: boolean;
  entry: Entry | null;
  error: string | null;
  onSave: () => void;
  onDownload: () => void;
  isSaved: boolean;
}

const LoadingSkeleton: React.FC = () => (
  <div className="space-y-4 animate-pulse">
    <div className="w-full aspect-video bg-slate-700 rounded-lg"></div>
    <div className="h-8 bg-slate-700 rounded w-3/4"></div>
    <div className="space-y-2">
      <div className="h-4 bg-slate-700 rounded"></div>
      <div className="h-4 bg-slate-700 rounded w-5/6"></div>
      <div className="h-4 bg-slate-700 rounded w-1/2"></div>
    </div>
    <div className="h-6 bg-slate-700 rounded w-1/3 mt-6"></div>
     <div className="space-y-2">
      <div className="h-4 bg-slate-700 rounded w-full"></div>
      <div className="h-4 bg-slate-700 rounded w-full"></div>
      <div className="h-4 bg-slate-700 rounded w-4/6"></div>
    </div>
  </div>
);

const WelcomeMessage: React.FC = () => (
  <div className="text-center py-10 px-4">
    <h2 className="text-2xl font-semibold text-slate-300 mb-2">Welcome to the Omniverse Archives</h2>
    <p className="text-slate-400">
      Enter a topic in the search bar above or select a suggestion to begin your exploration.
      The BIOS AI will generate a detailed codex entry, complete with a visual representation, for any concept within this infinite sanctuary.
    </p>
  </div>
);

export const ContentDisplay: React.FC<ContentDisplayProps> = ({ isLoading, entry, error, onSave, onDownload, isSaved }) => {
  if (isLoading) {
    return (
      <div className="mt-8 p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
        <LoadingSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mt-8 p-6 bg-red-900/20 border border-red-500/50 text-red-300 rounded-lg">
        <h3 className="font-bold text-lg mb-2">Archive Retrieval Error</h3>
        <p>{error}</p>
      </div>
    );
  }

  if (!entry) {
    return (
       <div className="mt-8 p-6 bg-slate-800/50 border border-slate-700/50 rounded-lg">
        <WelcomeMessage />
       </div>
    );
  }

  // A simple markdown-like parser for bold text.
  const formatContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, index) => {
      if (line.trim().startsWith('**') && line.trim().endsWith('**')) {
        return <h3 key={index} className="text-xl font-bold text-cyan-400 mt-4 mb-2">{line.replace(/\*\*/g, '')}</h3>;
      }
      if (line.trim() === '') {
        return <br key={index} />;
      }
      return <p key={index} className="mb-3">{line}</p>;
    });
  };
  
  const saveButtonClass = isSaved 
    ? "flex items-center gap-2 px-4 py-2 text-sm bg-teal-500/20 border border-teal-500 text-teal-300 rounded-full cursor-default"
    : "flex items-center gap-2 px-4 py-2 text-sm bg-slate-700/50 border border-slate-600 text-slate-300 rounded-full hover:bg-slate-700 hover:border-cyan-500 transition-all";


  return (
    <article className="mt-8 bg-slate-800/50 border border-slate-700 rounded-lg overflow-hidden">
       {entry.imageUrl && (
        <img 
          src={entry.imageUrl} 
          alt={`AI-generated image of ${entry.topic}`} 
          className="w-full h-auto max-h-[400px] object-cover bg-slate-700"
        />
      )}
      <div className="p-6">
        <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4 mb-4">
            <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-teal-400 capitalize flex-1">
                Codex Entry: {entry.topic}
            </h2>
            <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={onSave} disabled={isSaved} className={saveButtonClass} aria-label={isSaved ? "Entry saved" : "Save entry"}>
                    <BookmarkIcon className="w-4 h-4" />
                    {isSaved ? 'Saved' : 'Save'}
                </button>
                 <button onClick={onDownload} className="flex items-center gap-2 px-4 py-2 text-sm bg-slate-700/50 border border-slate-600 text-slate-300 rounded-full hover:bg-slate-700 hover:border-cyan-500 transition-all" aria-label="Download entry as text file">
                    <DownloadIcon className="w-4 h-4" />
                    Download
                </button>
            </div>
        </div>
        <div className="text-slate-300 leading-relaxed prose prose-invert prose-p:text-slate-300 prose-headings:text-cyan-400">
            {formatContent(entry.text)}
        </div>
      </div>
    </article>
  );
};
