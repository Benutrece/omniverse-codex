import React from 'react';
import { Entry } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { BookOpenIcon } from './icons/BookOpenIcon';

interface SavedEntriesProps {
  entries: Entry[];
  onSelect: (entry: Entry) => void;
  onDelete: (id: string) => void;
}

export const SavedEntries: React.FC<SavedEntriesProps> = ({ entries, onSelect, onDelete }) => {
  if (entries.length === 0) {
    return null; // Don't render anything if there are no saved entries
  }

  return (
    <section className="mt-12">
      <div className="flex items-center gap-3 mb-6">
        <BookOpenIcon className="w-7 h-7 text-cyan-400" />
        <h2 className="text-3xl font-bold text-slate-200">Saved Archives</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {entries.map((entry) => (
          <div key={entry.id} className="group relative bg-slate-800 border border-slate-700 rounded-lg overflow-hidden transition-all duration-300 hover:border-cyan-500 hover:shadow-lg hover:shadow-cyan-500/10">
            <button onClick={() => onSelect(entry)} className="block w-full text-left focus:outline-none focus:ring-2 focus:ring-cyan-500 rounded-lg">
              <img
                src={entry.imageUrl || 'https://placehold.co/400x225/1e293b/94a3b8?text=No+Image'}
                alt={`Image of ${entry.topic}`}
                className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105 bg-slate-700"
              />
              <div className="p-3">
                <h3 className="font-bold text-slate-200 truncate group-hover:text-cyan-400">{entry.topic}</h3>
              </div>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(entry.id);
              }}
              aria-label={`Delete entry for ${entry.topic}`}
              className="absolute top-2 right-2 p-1.5 bg-slate-900/50 text-slate-400 rounded-full hover:bg-red-500 hover:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors"
            >
              <TrashIcon className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};
