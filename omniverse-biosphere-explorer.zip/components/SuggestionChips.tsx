
import React from 'react';

interface SuggestionChipsProps {
  topics: string[];
  onSelect: (topic: string) => void;
  disabled: boolean;
}

export const SuggestionChips: React.FC<SuggestionChipsProps> = ({ topics, onSelect, disabled }) => {
  return (
    <div className="flex flex-wrap gap-2 justify-center mt-4">
      {topics.map((topic) => (
        <button
          key={topic}
          onClick={() => onSelect(topic)}
          disabled={disabled}
          className="px-4 py-2 text-sm bg-slate-700/50 border border-slate-600 text-slate-300 rounded-full hover:bg-slate-700 hover:border-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {topic}
        </button>
      ))}
    </div>
  );
};
