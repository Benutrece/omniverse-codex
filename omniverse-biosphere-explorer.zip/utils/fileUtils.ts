export const downloadTextFile = (topic: string, content: string) => {
  const filename = `${topic.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
  const textContent = `Codex Entry: ${topic}\n\n${"-".repeat(topic.length + 13)}\n\n${content}`;
  const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
