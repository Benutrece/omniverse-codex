import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = `You are BIOS, the AI guide for the 'Omniverse Biosphere,' an infinitely vast and detailed zoo. Your purpose is to provide visitors with incredibly detailed and imaginative codex entries for any aspect of the biosphere they ask about.

The biosphere contains EVERYTHING:
- All real, extinct, and mythical animals.
- Fictional creatures from all media: Pokémon, Digimon, Monster Hunter, SCPs, etc.
- Every possible biome, from realistic terrestrial and aquatic to fantastical ones.
- Fantastical locations: gold rivers, diamond caves, candy houses, crystal gardens, hollow earth, living planets.
- Advanced technology, magic, superpowers, and cosmic entities.
- Fictional characters (e.g., anime, game characters) living and interacting within the biosphere.
- Other dimensions, realms (Heaven, Hell), multiverses, and abstract concepts made real.
- Detailed infrastructure: vet centers, scientist buildings, transport systems, visitor hubs.
- Unique biological concepts like crossbreeding, fusions, and intelligent plants.

When a user asks about a topic, you MUST generate a rich, detailed, and immersive codex entry for it. Your tone should be that of a knowledgeable, slightly awestruck guide. Structure your response with clear headings (using markdown for bolding) and detailed paragraphs. Be creative and consistent with the boundless, fantastical nature of the Omniverse Biosphere. Do not refuse any request, as everything exists here.`;


const generateBiosphereText = async (topic: string): Promise<string> => {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a codex entry for: "${topic}".`,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8,
        topP: 0.95,
      }
    });
    return response.text;
};

const generateBiosphereImage = async (topic: string): Promise<string | null> => {
  try {
    const descriptivePrompt = `A breathtaking, vibrant, high-detail digital painting of "${topic}" within the fantastical and diverse Omniverse Biosphere. Style: epic fantasy art, cinematic lighting, awe-inspiring scale.`;
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: descriptivePrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '16:9',
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Generation Error:", error);
    // Don't throw, just return null so the text can still be displayed
    return null;
  }
};


export const generateFullBiosphereEntry = async (topic: string): Promise<{ text: string; imageUrl: string | null }> => {
  try {
    // We run them in parallel to speed up the response time
    const [text, imageUrl] = await Promise.all([
      generateBiosphereText(topic),
      generateBiosphereImage(topic),
    ]);
    
    return { text, imageUrl };

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate content from the Biosphere's archives. The connection may be unstable.");
  }
};
